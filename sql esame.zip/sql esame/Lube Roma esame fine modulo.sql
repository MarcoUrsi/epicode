CREATE DATABASE LubeRoma;

CREATE TABLE Customer (
CustomerID int,
FirstName varchar(25),
LastName varchar(25),
Age int,
EmailAddress varchar(50),
HouseAddress varchar(50),
Citt� varchar(25),
CONSTRAINT PK_Customer_CustomerID PRIMARY KEY (CustomerID));

INSERT INTO Customer
VALUES ( 10001, 'Marco', 'Ursi', 27, 'marco@gmail.com', 'Via tromarancia', 'Roma'),
       ( 10002 , 'Francesca' , 'Ruggiero' , 25 , 'rugg@gmail.com' , 'Via Roma 9' , 'Ciampino'),
	   ( 10003 , 'Marcello' , 'Mancini' , 64 , 'marcello@gmail.com' , 'Via Rose' , 'Albano' ),
       ( 10004 , 'Catherina' , 'Roletti' , 55 , 'roletti@gmail.com' , 'Via Roma 9' , 'Genzano' ),
	   ( 10005 , 'Matteo' , 'Bernasconi' , 33 , 'matteo@gmail.com' , 'Via Troma 77' , 'Roma' ),
       ( 10006 , 'Federico' , 'Rossi' , 37 , 'fede@gmail.com' , 'Via Lungomare 33' , 'Anzio' ),
	   ( 10007 , 'Falvio' , 'Bianchi' , 44 , 'flavio@gmail.com' , 'Via Rosetti 6' , 'Albano' ),
       ( 10008 , 'Emanuele' , 'Corsini' , 24 , 'corsini@gmail.com' , 'Via Gelsomino 55' , 'Genzano' ),
	   ( 10009 , 'Manuel' , 'Ursi' , 27 , 'marco@gmail.com' , 'Via Margherita 8' , 'Roma' ),
       ( 10010 , 'Francesco' , 'Raso' , 25 , 'rugg@gmail.com' , 'Via Menta 7' , 'Ciampino' ),
	   ( 10011 , 'Cristiano' , 'Mancino' , 64 , 'marcello@gmail.com' , 'Via Alighieri 5' , 'Roma' ),
       ( 10012 , 'Michelangrlo' , 'Rolle' , 55 , 'roletti@gmail.com' , 'Via Manzoni 9' , 'Genzano' ),
	   ( 10013 , 'Cristian' , 'De Rossi' , 33 , 'matteo@gmail.com' , 'Via Girasole 34' , 'Roma' ),
       ( 10014 , 'Roberto' , 'Rosso' , 37 , 'fede@gmail.com' , 'Via Roma 67' , 'Roma' ),
	   ( 10015 , 'Ivan' , 'Marciano' , 44 , 'flavio@gmail.com' , 'Via Rosellina 89' , 'Albano' ),
       ( 10016 , 'Lucia' , 'De Luca' , 24 , 'corsini@gmail.com' , 'Via Rimini 67' , 'Roma' ),
	   ( 10017 , 'Cristina' , 'Di Luccia' , 33 , 'matteo@gmail.com' , 'Via Girasole 34' , 'Roma' ),
       ( 10018 , 'Raubo' , 'Nero' , 37 , 'fede@gmail.com' , 'Via Roma 67' ,'Roma' ),
	   ( 10019 , 'Ivana' , 'Nerini' , 44 , 'flavio@gmail.com' , 'Via Rosellina 89' , 'Albano' ),
       ( 10020 , 'Luciano' , 'Antonucci' , 24 , 'corsini@gmail.com' , 'Via Rimini 67' , 'Roma' ),
	   ( 10021, 'Antonio', 'Ursi', 47, 'antou@gmail.com', 'Via svezzia 4', 'Roma'),
       ( 10022 , 'Paolo' , 'Ruggiero' , 25 , 'paolor@gmail.com' , 'Via siviglia 9' , 'Ciampino'),
	   ( 10023 , 'Massimo' , 'Mancini' , 74 , 'mass@gmail.com' , 'Via Rosetti 6' , 'Roma' ),
       ( 10024 , 'Rocco' , 'Roletti' , 45 , 'rocco@gmail.com' , 'Via Romania 44' , 'Genzano' ),
	   ( 10025 , 'Francesco' , 'Bernasconi' , 44 , 'frab@gmail.com' , 'Via Romania 77' , 'Roma' ),
       ( 10026 , 'Federica' , 'Rossi' , 27 , 'federossi@gmail.com' , 'Via arco 33' , 'Anzio' ),
	   ( 10027 , 'Falvia' , 'Bianchi' , 34 , 'flaviob@gmail.com' , 'Via francia 6' , 'Albano' ),
       ( 10028 , 'Emanuela' , 'Corsini' , 25 , 'emanuelac@gmail.com' , 'Via genzano 55' , 'Roma' ),
	   ( 10029 , 'Manuele' , 'Ursi' , 29 , 'manueleu@gmail.com' , 'Via Roma 8' , 'Roma' ),
       ( 10030 , 'Franco' , 'Raso' , 22 , 'raso@gmail.com' , 'Via taranto 7' , 'Ciampino' ),
	   ( 10031 , 'Cristina' , 'Mancino' , 25 , 'crima@gmail.com' , 'Via eugenio 5' , 'Roma' ),
       ( 10032 , 'Lucilla' , 'Rolle' , 58 , 'lucilla@gmail.com' , 'Via Manzoni 23' , 'Genzano' ),
	   ( 10033 , 'Franca' , 'De Rossi' , 38 , 'francadr@gmail.com' , 'Via del mare 54' , 'Roma' ),
       ( 10034 , 'Giualia' , 'Rosso' , 38 , 'giuliar@gmail.com' , 'Via ardeatina 67' , 'Roma' ),
	   ( 10035 , 'Serena' , 'Marciano' , 47 , 'serenam@gmail.com' , 'Via laurentina 89' , 'Roma' ),
       ( 10036 , 'Marco' , 'De Luca' , 64 , 'marcol@gmail.com' , 'Via della chiave 67' , 'Roma' ),
	   ( 10037 , 'Massimiliano' , 'Di Luccia' , 53 , 'massidiluccia@gmail.com' , 'Via russia 34' , 'Roma' ),
       ( 10038 , 'Razvan' , 'Nero' , 27 , 'razvan@gmail.com' , 'Via Roma 55' ,'Roma' ),
	   ( 10039 , 'Luca' , 'Nerini' , 54 , 'lucan@gmail.com' , 'Via san giovanni 89' , 'Roma' ),
       ( 10040 , 'Noemi' , 'Antonucci' , 44 , 'noemi@gmail.com' , 'Via siviglia 67' , 'Roma' );

CREATE TABLE SalesOrderHeader (
OrderID int,
OrderDate date,
PaymentMethod varchar(25),
CustomerID int,
CONSTRAINT PK_SalesOrderHeader_OrderID PRIMARY KEY (OrderID),
CONSTRAINT FK_SalesOrderHeader_Customer_CustomerID
        FOREIGN KEY (CustomerID)
		REFERENCES Customer (CustomerID));

INSERT INTO SalesOrderHeader
VALUES ( 20001, '02/02/2022', 'Mastercard', 10001),
       ( 20002, '05/02/2022', 'Mastercard', 10002),
	   ( 20003, '25/02/2022', 'Cash', 10003),
       ( 20004, '11/02/2022', 'Cash', 10004),
	   ( 20005, '24/02/2022', 'Mastercard', 10005),
       ( 20006, '11/02/2022', 'Mastercard', 10006),
	   ( 20007, '18/03/2022', 'Mastercard', 10007),
       ( 20008, '23/03/2022', 'Mastercard', 10008),
	   ( 20009, '01/03/2022', 'Mastercard', 10009),
       ( 20010, '22/03/2022', 'Mastercard', 10010),
	   ( 20011, '17/04/2022', 'Mastercard', 10011),
       ( 20012, '16/04/2022', 'Mastercard', 10012),
	   ( 20013, '26/04/2022', 'Cash', 10013),
       ( 20014, '12/04/2022', 'Cash', 10014),
	   ( 20015, '08/04/2022', 'Cash', 10015),
       ( 20016, '01/04/2022', 'Mastercard', 10016),
	   ( 20017, '03/05/2022', 'Mastercard', 10017),
       ( 20018, '07/05/2022', 'Cash', 10018),
	   ( 20019, '04/05/2022', 'Mastercard', 10019),
       ( 20020, '20/05/2022', 'Mastercard', 10020),
	   ( 20021, '02/06/2022', 'Mastercard', 10021),
       ( 20022, '05/06/2022', 'Mastercard', 10022),
	   ( 20023, '25/06/2022', 'Cash', 10023),
       ( 20024, '11/06/2022', 'Cash', 10024),
	   ( 20025, '24/06/2022', 'Mastercard', 10025),
       ( 20026, '11/06/2022', 'Mastercard', 10026),
	   ( 20027, '18/07/2022', 'Mastercard', 10027),
       ( 20028, '23/07/2022', 'Mastercard', 10028),
	   ( 20029, '01/07/2022', 'Mastercard', 10029),
       ( 20030, '22/07/2022', 'Mastercard', 10030),
	   ( 20031, '17/07/2022', 'Mastercard', 10031),
       ( 20032, '16/07/2022', 'Mastercard', 10032),
	   ( 20033, '26/07/2022', 'Cash', 10033),
       ( 20034, '12/07/2022', 'Cash', 10034),
	   ( 20035, '08/08/2022', 'Cash', 10035),
       ( 20036, '01/08/2022', 'Mastercard', 10036),
	   ( 20037, '03/08/2022', 'Mastercard', 10037),
       ( 20038, '07/08/2022', 'Cash', 10038),
	   ( 20039, '04/08/2022', 'Mastercard', 10039),
       ( 20040, '20/08/2022', 'Mastercard', 10040);

CREATE TABLE SalesOrderDetail (
OrderID int,
LineItemNo int,
Quantity int,
UnitPrice money,
ProductID int,
EmployeeID int,
CONSTRAINT PK_SalesOrderDetail_OrderID_LineItemNo PRIMARY KEY (OrderID, LineItemNo),
CONSTRAINT FK_SalesOrderDetail_Product_ProductID
        FOREIGN KEY (ProductID)
		REFERENCES Product (ProductID),
CONSTRAINT FK_SalesOrderDetail_Employee_EmployeeID
        FOREIGN KEY (EmployeeID)
		REFERENCES Employee (EmployeeID));

INSERT INTO SalesOrderDetail
VALUES ( 20001, 1, 4, '130', 40001, 70001),
       ( 20001, 2, 4, '160', 40002, 70001),
	   ( 20001, 3, 1, '2200', 40003, 70001),
	   ( 20001, 4, 1, '1500', 40004, 70001),
	   ( 20002, 1, 6, '110', 40005, 70002),
       ( 20002, 2, 6, '140', 40006, 70002),
	   ( 20002, 3, 1, '2000', 40007, 70002),
	   ( 20002, 4, 1, '1300', 40008, 70002),
	   ( 20003, 1, 4, '190', 40009, 70001),
       ( 20003, 2, 7, '240', 40010, 70001),
	   ( 20003, 3, 1, '2800', 40011, 70001),
	   ( 20003, 4, 1, '1500', 40012, 70001),
	   ( 20004, 1, 6, '110', 40013, 70001),
       ( 20004, 2, 6, '140', 40014, 70001),
	   ( 20004, 3, 1, '2000', 40015, 70001),
	   ( 20004, 4, 1, '1300', 40016, 70001),
	   ( 20005, 1, 4, '110', 40005, 70002),
       ( 20005, 2, 4, '140', 40006, 70002),
	   ( 20005, 3, 1, '2000', 40007, 70002),
	   ( 20005, 4, 1, '1300', 40008, 70002),
	   ( 20006, 1, 6, '130', 40001, 70003), 
       ( 20006, 2, 6, '160', 40002, 70003),
	   ( 20006, 3, 1, '2200', 40003, 70003),
	   ( 20007, 1, 6, '190', 40009, 70004),
	   ( 20007, 2, 6, '240', 40010, 70004),
       ( 20007, 3, 1, '2800', 40011, 70004),
	   ( 20008, 1, 4, '190', 40009, 70005),
	   ( 20008, 2, 8, '240', 40010, 70005),
	   ( 20008, 3, 1, '2800', 40011, 70005),
       ( 20008, 4, 1, '1500', 40012, 70005),
	   ( 20009, 1, 3, '110', 40005, 70006),
	   ( 20009, 2, 4, '140', 40006, 70006),
	   ( 20009, 3, 1, '2000', 40007, 70006),
	   ( 20009, 4, 1, '1300', 40008, 70006),
	   ( 20010, 1, 8, '110', 40013, 70006),
	   ( 20010, 2, 8, '140', 40014, 70006),
	   ( 20010, 3, 1, '2000', 40015, 70006),
	   ( 20010, 4, 1, '1300', 40016, 70006),
	   ( 20011, 1, 8, '130', 40001, 70001),
       ( 20011, 2, 6, '160', 40002, 70001),
	   ( 20011, 3, 1, '2200', 40003, 70001),
	   ( 20011, 4, 1, '1500', 40004, 70001),
	   ( 20012, 1, 6, '110', 40005, 70006),
       ( 20012, 2, 8, '140', 40006, 70006),
	   ( 20012, 3, 1, '2000', 40007, 70006),
	   ( 20012, 4, 1, '1300', 40008, 70006),
	   ( 20013, 1, 7, '190', 40009, 70005),
       ( 20013, 2, 7, '240', 40010, 70005),
	   ( 20013, 3, 1, '2800', 40011, 70005),
	   ( 20013, 4, 1, '1500', 40012, 70005),
	   ( 20014, 1, 8, '110', 40013, 70001),
       ( 20014, 2, 6, '140', 40014, 70001),
	   ( 20014, 3, 1, '2000', 40015, 70001),
	   ( 20014, 4, 1, '1300', 40016, 70001),
	   ( 20015, 1, 4, '110', 40005, 70002),
       ( 20015, 2, 4, '140', 40006, 70002),
	   ( 20015, 3, 1, '2000', 40007, 70002),
	   ( 20015, 4, 1, '1300', 40008, 70002),
	   ( 20016, 1, 6, '130', 40001, 70003), 
       ( 20016, 2, 8, '160', 40002, 70003),
	   ( 20016, 3, 1, '2200', 40003, 70003),
	   ( 20017, 1, 6, '190', 40009, 70003),
	   ( 20017, 2, 6, '240', 40010, 70003),
       ( 20017, 3, 1, '2800', 40011, 70003),
	   ( 20018, 1, 8, '190', 40009, 70001),
	   ( 20018, 2, 8, '240', 40010, 70001),
	   ( 20018, 3, 1, '2800', 40011, 70001),
       ( 20018, 4, 1, '1500', 40012, 70001),
	   ( 20019, 1, 6, '110', 40005, 70005),
	   ( 20019, 2, 8, '140', 40006, 70005),
	   ( 20019, 3, 1, '2000', 40007, 70005),
	   ( 20019, 4, 1, '1300', 40008, 70005),
	   ( 20020, 1, 8, '110', 40013, 70003),
	   ( 20020, 2, 8, '140', 40014, 70003),
	   ( 20020, 3, 1, '2000', 40015, 70003),
	   ( 20020, 4, 1, '1300', 40016, 70003),
	   ( 20021, 1, 4, '130', 40001, 70001),
       ( 20021, 2, 4, '160', 40002, 70001),
	   ( 20021, 3, 1, '2200', 40003, 70001),
	   ( 20021, 4, 1, '1500', 40004, 70001),
	   ( 20022, 1, 6, '110', 40005, 70002),
       ( 20022, 2, 6, '140', 40006, 70002),
	   ( 20022, 3, 1, '2000', 40007, 70002),
	   ( 20022, 4, 1, '1300', 40008, 70002),
	   ( 20023, 1, 4, '190', 40009, 70001),
       ( 20023, 2, 7, '240', 40010, 70001),
	   ( 20023, 3, 1, '2800', 40011, 70001),
	   ( 20023, 4, 1, '1500', 40012, 70001),
	   ( 20024, 1, 6, '110', 40013, 70001),
       ( 20024, 2, 6, '140', 40014, 70001),
	   ( 20024, 3, 1, '2000', 40015, 70001),
	   ( 20024, 4, 1, '1300', 40016, 70001),
	   ( 20025, 1, 4, '110', 40005, 70002),
       ( 20025, 2, 4, '140', 40006, 70002),
	   ( 20025, 3, 1, '2000', 40007, 70002),
	   ( 20025, 4, 1, '1300', 40008, 70002),
	   ( 20026, 1, 6, '130', 40001, 70003), 
       ( 20026, 2, 6, '160', 40002, 70003),
	   ( 20026, 3, 1, '2200', 40003, 70003),
	   ( 20027, 1, 6, '190', 40009, 70004),
	   ( 20027, 2, 6, '240', 40010, 70004),
       ( 20027, 3, 1, '2800', 40011, 70004),
	   ( 20028, 1, 4, '190', 40009, 70005),
	   ( 20028, 2, 8, '240', 40010, 70005),
	   ( 20028, 3, 1, '2800', 40011, 70005),
       ( 20028, 4, 1, '1500', 40012, 70005),
	   ( 20029, 1, 3, '110', 40005, 70006),
	   ( 20029, 2, 4, '140', 40006, 70006),
	   ( 20029, 3, 1, '2000', 40007, 70006),
	   ( 20029, 4, 1, '1300', 40008, 70006),
	   ( 20030, 1, 8, '110', 40013, 70006),
	   ( 20030, 2, 8, '140', 40014, 70006),
	   ( 20030, 3, 1, '2000', 40015, 70006),
	   ( 20030, 4, 1, '1300', 40016, 70006),
	   ( 20031, 1, 8, '130', 40001, 70001),
       ( 20031, 2, 6, '160', 40002, 70001),
	   ( 20031, 3, 1, '2200', 40003, 70001),
	   ( 20031, 4, 1, '1500', 40004, 70001),
	   ( 20032, 1, 6, '110', 40005, 70006),
       ( 20032, 2, 8, '140', 40006, 70006),
	   ( 20032, 3, 1, '2000', 40007, 70006),
	   ( 20032, 4, 1, '1300', 40008, 70006),
	   ( 20033, 1, 7, '190', 40009, 70005),
       ( 20033, 2, 7, '240', 40010, 70005),
	   ( 20033, 3, 1, '2800', 40011, 70005),
	   ( 20033, 4, 1, '1500', 40012, 70005),
	   ( 20034, 1, 8, '110', 40013, 70001),
       ( 20034, 2, 6, '140', 40014, 70001),
	   ( 20034, 3, 1, '2000', 40015, 70001),
	   ( 20034, 4, 1, '1300', 40016, 70001),
	   ( 20035, 1, 4, '110', 40005, 70002),
       ( 20035, 2, 4, '140', 40006, 70002),
	   ( 20035, 3, 1, '2000', 40007, 70002),
	   ( 20035, 4, 1, '1300', 40008, 70002),
	   ( 20036, 1, 6, '130', 40001, 70003), 
       ( 20036, 2, 8, '160', 40002, 70003),
	   ( 20036, 3, 1, '2200', 40003, 70003),
	   ( 20037, 1, 6, '190', 40009, 70003),
	   ( 20037, 2, 6, '240', 40010, 70003),
       ( 20037, 3, 1, '2800', 40011, 70003),
	   ( 20038, 1, 8, '190', 40009, 70001),
	   ( 20038, 2, 8, '240', 40010, 70001),
	   ( 20038, 3, 1, '2800', 40011, 70001),
       ( 20038, 4, 1, '1500', 40012, 70001),
	   ( 20039, 1, 6, '110', 40005, 70005),
	   ( 20039, 2, 8, '140', 40006, 70005),
	   ( 20039, 3, 1, '2000', 40007, 70005),
	   ( 20039, 4, 1, '1300', 40008, 70005),
	   ( 20040, 1, 8, '110', 40013, 70003),
	   ( 20040, 2, 8, '140', 40014, 70003),
	   ( 20040, 3, 1, '2000', 40015, 70003),
	   ( 20040, 4, 1, '1300', 40016, 70003);

CREATE TABLE Product (
ProductID int,
ProductName varchar(50),
Color varchar(25),
ProductStandardCost money,
KitchenModelID int,
CONSTRAINT PK_Product_ProductID PRIMARY KEY (ProductID),
CONSTRAINT FK_Product_KitchenModel_KitchenModelID
        FOREIGN KEY (KitchenModelID)
		REFERENCES KitchenModel (KitchenModelID));

INSERT INTO Product
VALUES ( 40001, 'pensile', 'bianco', '100', 50001),
       ( 40002, 'base', 'bianco', '120', 50001),
	   ( 40003, 'top', 'bianco', '1500', 50001),
	   ( 40004, 'elettrodomestici', 'bianco', '1000', 50001),
	   ( 40005, 'pensile', 'nero', '80', 50002),
       ( 40006, 'base', 'nero', '100', 50002),
	   ( 40007, 'top', 'nero', '1700', 50002),
	   ( 40008, 'elettrodomestici', 'nero', '800', 50002),
	   ( 40009, 'pensile', 'legno', '150', 50003),
       ( 40010, 'base', 'legno', '200', 50003),
	   ( 40011, 'top', 'legno', '1900', 50003),
	   ( 40012, 'elettrodomestici', 'grigio opaco', '1000', 50003),
	   ( 40013, 'pensile', 'grigio', '70', 50004),
       ( 40014, 'base', 'grigio', '80', 50004),
	   ( 40015, 'top', 'grigio', '1400', 50004),
	   ( 40016, 'elettrodomestici', 'grigio', '1000', 50004);

CREATE TABLE KitchenModel (
KitchenModelID int,
KitchenName varchar(25),
CONSTRAINT PK_KitchenModel_KitchenModelID PRIMARY KEY (KitchenModelID));

INSERT INTO KitchenModel
VALUES (50001, 'Tabletneck'),
       (50002, 'Kyra'),
	   (50003, 'Imagine'),
	   (50004, 'Dream');

CREATE TABLE Reseller (
ResellerID int,
ResellerName varchar(25),
ResellerAddress varchar(50),
Citt� varchar(25),
EmailAddress varchar (50),
WarehouseID int,
CONSTRAINT PK_Reseller_ResellerID PRIMARY KEY (resellerID),
CONSTRAINT FK_Reseller_WarehouseID
       FOREIGN KEY (WarehouseID)
	   REFERENCES Warehouse (WarehouseID));

INSERT INTO Reseller 
VALUES ( 30001, 'Meb', 'Via Tuscolana', 'Roma', 'lubetuscoalna@gmail.com', 60001),
       ( 30002, 'Ad Interni', 'Via Prati', 'Roma', 'lubeprati@gmail.com', 60001),
	   ( 30003, 'Aurelia', 'Via Arurelia', 'Roma', 'lubeaurelia@gmail.com', 60002);

CREATE TABLE Employee (
EmployeeID int,
FirstName varchar (25),
NumberPhone varchar(25),
Age int,
ResellerID int,
CONSTRAINT PK_Employee_EmployeeID PRIMARY KEY (EmployeeID),
CONSTRAINT FK_Employee_ResellerID
        FOREIGN KEY (ResellerID)
		REFERENCES Reseller (ResellerID));

INSERT INTO Employee
VALUES ( 70001, 'Filippo', '3667829344', '44', 30001),
       ( 70002, 'Alessandro', '3387678922', '50', 30001),
	   ( 70003, 'Donato', '3367782983', '65', 30002),
	   ( 70004, 'Marco', '3556728378', '48', 30002),
	   ( 70005, 'Mauro', '3662789367', '38', 30003),
	   ( 70006, 'Raimondo', '3387890908', '28', 30003);

CREATE TABLE Warehouse (
WarehouseID int,
WarehouseAddress varchar(50)
CONSTRAINT PK_Warehouse_WarehouseID PRIMARY KEY (WarehouseID));

INSERT INTO Warehouse 
VALUES ( 60001, 'Via Montenegro 5'),
       ( 60002, 'Via Aurelia 7');

CREATE TABLE Stock (
StockID int,
DateArrival date,
DateExit date,
WarehouseID int,
CONSTRAINT PK_Stock_StockID PRIMARY KEY (StockID),
CONSTRAINT FK_Stock_WarehouseID
        FOREIGN KEY (WarehouseID)
		REFERENCES Warehouse (WarehouseID));

INSERT INTO Stock 
VALUES ( 80001, '02/03/2022', '04/04/2022', 60001),
       ( 80002, '05/03/2022', '03/04/2022', 60001),
	   ( 80003, '25/03/2022', '27/04/2022', 60001),
       ( 80004, '11/03/2022', '15/04/2022', 60001),
	   ( 80005, '24/03/2022', '28/04/2022', 60001),
       ( 80006, '11/03/2022', '15/04/2022', 60001),
	   ( 80007, '18/04/2022', '22/05/2022', 60001),
       ( 80008, '23/04/2022', '25/05/2022', 60002),
	   ( 80009, '01/04/2022', '01/05/2022', 60002),
       ( 80010, '22/04/2022', '24/05/2022', 60002),
	   ( 80011, '17/05/2022', '19/06/2022', 60001),
       ( 80012, '16/05/2022', '18/06/2022', 60002),
	   ( 80013, '26/05/2022', '28/06/2022', 60002),
       ( 80014, '12/05/2022', '15/06/2022', 60001),
	   ( 80015, '08/05/2022', '08/06/2022', 60001),
       ( 80016, '01/05/2022', '03/06/2022', 60001),
	   ( 80017, '03/06/2022', '05/07/2022', 60001),
       ( 80018, '07/06/2022', '08/07/2022', 60001),
	   ( 80019, '04/06/2022', '06/07/2022', 60002),
       ( 80020, '20/06/2022', '20/07/2022', 60001),
	   ( 80021, '02/07/2022', null, 60001),
       ( 80022, '05/07/2022', null, 60001),
	   ( 80023, '25/07/2022', null, 60001),
       ( 80024, '11/07/2022', null, 60001),
	   ( 80025, '24/07/2022', null, 60001),
       ( 80026, '11/07/2022', null, 60001),
	   ( 80027, '18/08/2022', null, 60001),
       ( 80028, '23/08/2022', null, 60002),
	   ( 80029, '01/08/2022', null, 60002),
       ( 80030, '22/08/2022', null, 60002),
	   ( 80031, '17/08/2022', null, 60001),
       ( 80032, '16/08/2022', null, 60002),
	   ( 80033, '26/08/2022', null, 60002),
       ( 80034, '12/08/2022', null, 60001),
	   ( 80035, '08/09/2022', null, 60001),
       ( 80036, '01/09/2022', null, 60001),
	   ( 80037, '03/09/2022', null, 60001),
       ( 80038, '07/09/2022', null, 60001),
	   ( 80039, '04/09/2022', null, 60002),
       ( 80040, '20/09/2022', null, 60001);


/** interroghiamo i dati **/
SELECT *
FROM Employee AS e
INNER JOIN SalesOrderDetail AS s
ON e.EmployeeID = s.EmployeeID

SELECT s.OrderID, s.EmployeeID, COUNT(Quantity) 
FROM Employee AS e
INNER JOIN SalesOrderDetail AS s
ON e.EmployeeID = s.EmployeeID
GROUP BY s.OrderID, s.EmployeeID
HAVING s.EmployeeID = 70001

---------------------
SELECT OrderID, SUM(Quantity * UnitPrice)
FROM SalesOrderDetail
GROUP BY OrderID

SELECT *
FROM SalesOrderDetail

---------------------
SELECT *
FROM Employee

SELECT *
FROM Employee AS em

SELECT DISTINCT e.EmployeeID, e.FirstName, s.OrderID, SUM(Quantity * UnitPrice) AS PrezzoCucina
FROM Employee AS e
INNER JOIN SalesOrderDetail AS s
ON e.EmployeeID = s.EmployeeID
GROUP BY s.OrderID, e.EmployeeID, e.FirstName
----------------------------
SELECT e.FirstName, e.EmployeeID, SUM(Quantity * UnitPrice)
FROM Employee e
INNER JOIN SalesOrderDetail s
ON e.EmployeeID = s.EmployeeID
GROUP BY e.FirstName, e.EmployeeID

-----------------------------------

SELECT r.ResellerID, r.ResellerName, SUM(Quantity * UnitPrice)
FROM Employee e
INNER JOIN SalesOrderDetail s
ON e.EmployeeID = s.EmployeeID
INNER JOIN Reseller AS r
ON r.ResellerID = e.ResellerID
GROUP BY r.ResellerID, r.ResellerName

------------------------------
