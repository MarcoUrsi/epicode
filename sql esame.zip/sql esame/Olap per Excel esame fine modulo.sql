CREATE VIEW MR_vDimCustumer AS (
SELECT c.CustomerID, ca.CustomerAddressID, c.FirstName, c.LastName, c.Age, c.EmailAddress, s.PaymentMethod ,s.OrderDate AS DatePourchase
FROM Customer AS c
INNER JOIN CustomerAddress AS ca
ON c.CustomerAddressID = ca.CustomerAddressID
INNER JOIN SalesOrderHeader AS s
ON c.CustomerID = s.CustomerID);

CREATE VIEW MR_vDimGeography AS (
SELECT CustomerAddressID, HouseAddress, NameCity, NameProvince
FROM CustomerAddress
UNION ALL
SELECT ResellerAddressID, ResellerAddress, NameCity, NameProvince
FROM ResellerAddress);

CREATE VIEW MR_vDimReseller AS (
SELECT r.ResellerID, ra.ResellerAddressID, r.ResellerName, r.EmailAddress, ra.ResellerAddress, w.WarehouseID, w.NameWarehouse
FROM Reseller AS r
INNER JOIN ResellerAddress AS ra
ON r.ReselleraddressID = ra.ResellerAddressID
INNER JOIN Warehouse AS w
ON r.WarehouseID = w.WarehouseID);

CREATE VIEW MR_vDimProduct AS (
SELECT p.ProductID, k.KitchenModelID, k.KitchenName, p.ProductName, p.ProductStandardCost, p.Color
FROM Product AS p
INNER JOIN KitchenModel AS k
ON p.KitchenModelID = k.KitchenModelID);

CREATE VIEW MR_vDimEmployee AS (
SELECT e.EmployeeID, e.FirstName, e.Lastname, e.EmailAddress, e.NumberPhone, e.Age, r.ResellerID, r.ResellerName
FROM Employee AS e
INNER JOIN Reseller AS r
ON e.ResellerID = r.ResellerID);

CREATE VIEW MR_vFactResellerSales AS (
SELECT sod.OrderID, soh.OrderDate, s.DateArrival, s.DateExit, e.EmployeeID, r.ResellerID, s.WarehouseID, p.ProductID, p.ProductStandardCost, sod.UnitPrice, sod.Quantity
--SUM(p.ProductStandardCost * sod.Quantity) AS TotalStandardCost, SUM(sod.UnitPrice * sod.Quantity) AS SalesAmount
FROM SalesOrderHeader AS soh
INNER JOIN SalesOrderDetail AS sod
ON soh.OrderID = sod.OrderID
INNER JOIN Employee AS e
ON sod.EmployeeID = e.EmployeeID
INNER JOIN Reseller AS r
ON e.ResellerID = r.ResellerID
INNER JOIN StockManagement AS s
ON soh.OrderID = s.OrderID
INNER JOIN Product AS p
ON sod.ProductID = p.ProductID);

