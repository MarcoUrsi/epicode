CREATE DATABASE LubeRomaEsercizioFineModulo;

CREATE TABLE CustomerAddress (
CustomerAddressID int,
HouseAddress varchar(50),
NameCity varchar(25),
NameProvince varchar(25),
CONSTRAINT PK_CustomerAddress_CustomerAddressID PRIMARY KEY (CustomerAddressID));

INSERT INTO CustomerAddress
VALUES ( 110001, 'Via tromarancia', 'Roma' , 'Roma'),
       ( 110002, 'Via Roma 9' , 'Ciampino', 'Roma'),
       ( 110003, 'Via Rose' , 'Cisterna di Latina', 'Latina'),
       ( 110004, 'Via Roma 9' , 'Genzano', 'Roma' ),
       ( 110005, 'Via Troma 77' , 'Roma', 'Roma'),
       ( 110006, 'Via Lungomare 33' , 'Anzio', 'Roma'),
       ( 110007, 'Via Rosetti 6' , 'Fiuggi', 'Frosinone'),
       ( 110008, 'Via Gelsomino 55' , 'Genzano', 'Roma'),
       ( 110009, 'Via Margherita 8' , 'Roma', 'Roma'),
       ( 110010, 'Via Menta 7' , 'Ciampino', 'Roma'),
       ( 110011, 'Via Alighieri 5' , 'Frosinone', 'Frosinone'),
       ( 110012, 'Via Manzoni 9' , 'Genzano', 'Roma'),
       ( 110013, 'Via Girasole 34' , 'Roma', 'Roma'),
       ( 110014, 'Via Roma 67' , 'Roma', 'Roma'),
       ( 110015, 'Via Rosellina 89' , 'Albano', 'Roma'),
       ( 110016, 'Via Rimini 67' , 'Ferentino', 'Frosinone'),
       ( 110017, 'Via Girasole 34' , 'Roma', 'Roma'),
       ( 110018, 'Via Roma 67' ,'Roma', 'Roma'),
       ( 110019, 'Via Rosellina 89' , 'Latina', 'Latina'),
       ( 110020, 'Via Rimini 67' , 'Roma', 'Roma'),
       ( 110021, 'Via svezzia 4', 'Roma', 'Roma'),
       ( 110022, 'Via siviglia 9' , 'Ciampino', 'Roma'),
       ( 110023, 'Via Rosetti 6' , 'Roma', 'Roma'),
       ( 110024, 'Via Romania 44' , 'Frosinone', 'Frosinone'),
       ( 110025, 'Via Romania 77' , 'Roma', 'Roma'),
       ( 110026, 'Via arco 33' , 'Cisterna di Latina', 'Latina'),
       ( 110027, 'Via francia 6' , 'Albano', 'Roma'),
       ( 110028, 'Via genzano 55' , 'Roma', 'Roma'),
       ( 110029, 'Via Roma 8' , 'Roma', 'Roma'),
       ( 110030, 'Via taranto 7' , 'Ferentino', 'Frosinone'),
       ( 110031, 'Via eugenio 5' , 'Roma', 'Roma'),
       ( 110032, 'Via Manzoni 23' , 'Genzano', 'Roma'),
       ( 110033, 'Via del mare 54' , 'Roma', 'Roma'),
       ( 110034, 'Via ardeatina 67' , 'Roma', 'Roma'),
       ( 110035, 'Via laurentina 89' , 'Roma', 'Roma'),
       ( 110036, 'Via della chiave 67' , 'Roma', 'Roma'),
       ( 110037, 'Via russia 34' , 'Roma', 'Roma'),
       ( 110038, 'Via Roma 55' ,'Roma', 'Roma'),
       ( 110039, 'Via san giovanni 89' , 'Roma', 'Roma'),
       ( 110040, 'Via siviglia 67' , 'Roma', 'Roma');



CREATE TABLE Customer (
CustomerID int,
FirstName varchar(25),
LastName varchar(25),
Age int,
EmailAddress varchar(50),
CustomerAddressID int,
CONSTRAINT PK_Customer_CustomerID PRIMARY KEY (CustomerID),
CONSTRAINT FK_Customer_CustomerAddress_CustomerAddressID
        FOREIGN KEY (CustomerAddressID)
		REFERENCES CustomerAddress (CustomerAddressID));

INSERT INTO Customer
VALUES ( 10001, 'Marco', 'Ursi', 27, 'marco@gmail.com', 110001),
       ( 10002, 'Francesca' , 'Ruggiero' , 25 , 'rugg@gmail.com', 110002) ,
	   ( 10003, 'Marcello' , 'Mancini' , 64 , 'marcello@gmail.com', 110003),
       ( 10004, 'Catherina' , 'Roletti' , 55 , 'roletti@gmail.com', 110004) ,
	   ( 10005, 'Matteo' , 'Bernasconi' , 33 , 'matteo@gmail.com', 110005) ,
       ( 10006, 'Federico' , 'Rossi' , 37 , 'fede@gmail.com', 110006),
	   ( 10007, 'Falvio' , 'Bianchi' , 44 , 'flavio@gmail.com', 110007),
       ( 10008, 'Emanuele' , 'Corsini' , 24 , 'corsini@gmail.com', 110008), 
	   ( 10009, 'Manuel' , 'Ursi' , 27 , 'marco@gmail.com', 110009), 
       ( 10010, 'Francesco' , 'Raso' , 25 , 'rugg@gmail.com', 110010), 
	   ( 10011, 'Cristiano' , 'Mancino' , 64 , 'marcello@gmail.com', 110011),
       ( 10012, 'Michelangrlo' , 'Rolle' , 55 , 'roletti@gmail.com', 110012),
	   ( 10013, 'Cristian' , 'De Rossi' , 33 , 'matteo@gmail.com', 110013), 
       ( 10014, 'Roberto' , 'Rosso' , 37 , 'fede@gmail.com', 110014), 
	   ( 10015, 'Ivan' , 'Marciano' , 44 , 'flavio@gmail.com', 110015), 
       ( 10016, 'Lucia' , 'De Luca' , 24 , 'corsini@gmail.com', 110016),
	   ( 10017, 'Cristina' , 'Di Luccia' , 33 , 'matteo@gmail.com', 110017), 
       ( 10018, 'Raubo' , 'Nero' , 37 , 'fede@gmail.com', 110018), 
	   ( 10019, 'Ivana' , 'Nerini' , 44 , 'flavio@gmail.com', 110019), 
       ( 10020, 'Luciano' , 'Antonucci' , 24 , 'corsini@gmail.com', 110020),
	   ( 10021, 'Antonio', 'Ursi', 47, 'antou@gmail.com', 110021),
       ( 10022, 'Paolo' , 'Ruggiero' , 25 , 'paolor@gmail.com', 110022), 
	   ( 10023, 'Massimo' , 'Mancini' , 74 , 'mass@gmail.com', 110023), 
       ( 10024, 'Rocco' , 'Roletti' , 45 , 'rocco@gmail.com', 110024), 
	   ( 10025, 'Francesco' , 'Bernasconi' , 44 , 'frab@gmail.com', 110025), 
       ( 10026, 'Federica' , 'Rossi' , 27 , 'federossi@gmail.com', 110026), 
	   ( 10027, 'Falvia' , 'Bianchi' , 34 , 'flaviob@gmail.com', 110027),
       ( 10028, 'Emanuela' , 'Corsini' , 25 , 'emanuelac@gmail.com', 110028), 
	   ( 10029, 'Manuele' , 'Ursi' , 29 , 'manueleu@gmail.com', 110029), 
       ( 10030, 'Franco' , 'Raso' , 22 , 'raso@gmail.com', 110030), 
	   ( 10031, 'Cristina' , 'Mancino' , 25 , 'crima@gmail.com', 110031), 
       ( 10032, 'Lucilla' , 'Rolle' , 58 , 'lucilla@gmail.com', 110032), 
	   ( 10033, 'Franca' , 'De Rossi' , 38 , 'francadr@gmail.com', 110033), 
       ( 10034, 'Giualia' , 'Rosso' , 38 , 'giuliar@gmail.com', 110034), 
	   ( 10035, 'Serena' , 'Marciano' , 47 , 'serenam@gmail.com', 110035), 
       ( 10036, 'Marco' , 'De Luca' , 64 , 'marcol@gmail.com', 110036), 
	   ( 10037, 'Massimiliano' , 'Di Luccia' , 53 , 'massidiluccia@gmail.com', 110037), 
       ( 10038, 'Razvan' , 'Nero' , 27 , 'razvan@gmail.com', 110038), 
	   ( 10039, 'Luca' , 'Nerini' , 54 , 'lucan@gmail.com', 110039), 
       ( 10040, 'Noemi' , 'Antonucci' , 44 , 'noemi@gmail.com', 110040); 

CREATE TABLE SalesOrderHeader (
OrderID int,
OrderDate date,
PaymentMethod varchar(25),
CustomerID int,
CONSTRAINT PK_SalesOrderHeader_OrderID PRIMARY KEY (OrderID),
CONSTRAINT FK_SalesOrderHeader_Customer_CustomerID
        FOREIGN KEY (CustomerID)
		REFERENCES Customer (CustomerID));

INSERT INTO SalesOrderHeader
VALUES ( 20001, '02/02/2022', 'Mastercard', 10001),
       ( 20002, '05/02/2022', 'Mastercard', 10002),
	   ( 20003, '25/02/2022', 'Cash', 10003),
       ( 20004, '11/02/2022', 'Cash', 10004),
	   ( 20005, '24/02/2022', 'Mastercard', 10005),
       ( 20006, '11/02/2022', 'Mastercard', 10006),
	   ( 20007, '18/03/2022', 'Mastercard', 10007),
       ( 20008, '23/03/2022', 'Mastercard', 10008),
	   ( 20009, '01/03/2022', 'Mastercard', 10009),
       ( 20010, '22/03/2022', 'Mastercard', 10010),
	   ( 20011, '17/04/2022', 'Mastercard', 10011),
       ( 20012, '16/04/2022', 'Mastercard', 10012),
	   ( 20013, '26/04/2022', 'Cash', 10013),
       ( 20014, '12/04/2022', 'Cash', 10014),
	   ( 20015, '08/04/2022', 'Cash', 10015),
       ( 20016, '01/04/2022', 'Mastercard', 10016),
	   ( 20017, '03/05/2022', 'Mastercard', 10017),
       ( 20018, '07/05/2022', 'Cash', 10018),
	   ( 20019, '04/05/2022', 'Mastercard', 10019),
       ( 20020, '20/05/2022', 'Mastercard', 10020),
	   ( 20021, '02/06/2022', 'Mastercard', 10021),
       ( 20022, '05/06/2022', 'Mastercard', 10022),
	   ( 20023, '25/06/2022', 'Cash', 10023),
       ( 20024, '11/06/2022', 'Cash', 10024),
	   ( 20025, '24/06/2022', 'Mastercard', 10025),
       ( 20026, '11/06/2022', 'Mastercard', 10026),
	   ( 20027, '18/07/2022', 'Mastercard', 10027),
       ( 20028, '23/07/2022', 'Mastercard', 10028),
	   ( 20029, '01/07/2022', 'Mastercard', 10029),
       ( 20030, '22/07/2022', 'Mastercard', 10030),
	   ( 20031, '17/07/2022', 'Mastercard', 10031),
       ( 20032, '16/07/2022', 'Mastercard', 10032),
	   ( 20033, '26/07/2022', 'Cash', 10033),
       ( 20034, '12/07/2022', 'Cash', 10034),
	   ( 20035, '08/08/2022', 'Cash', 10035),
       ( 20036, '01/08/2022', 'Mastercard', 10036),
	   ( 20037, '03/08/2022', 'Mastercard', 10037),
       ( 20038, '07/08/2022', 'Cash', 10038),
	   ( 20039, '04/08/2022', 'Mastercard', 10039),
       ( 20040, '20/08/2022', 'Mastercard', 10040);

CREATE TABLE SalesOrderDetail (
OrderID int,
LineItemNo int,
Quantity int,
UnitPrice money,
ProductID int,
EmployeeID int,
CONSTRAINT PK_SalesOrderDetail_OrderID_LineItemNo PRIMARY KEY (OrderID, LineItemNo),
CONSTRAINT FK_SalesOrderDetail_Product_ProductID
        FOREIGN KEY (ProductID)
		REFERENCES Product (ProductID),
CONSTRAINT FK_SalesOrderDetail_Employee_EmployeeID
        FOREIGN KEY (EmployeeID)
		REFERENCES Employee (EmployeeID));

INSERT INTO SalesOrderDetail
VALUES ( 20001, 1, 4, '130', 40001, 70001),
       ( 20001, 2, 4, '160', 40002, 70001),
	   ( 20001, 3, 1, '2200', 40003, 70001),
	   ( 20001, 4, 1, '1500', 40004, 70001),
	   ( 20002, 1, 6, '110', 40005, 70002),
       ( 20002, 2, 6, '140', 40006, 70002),
	   ( 20002, 3, 1, '2000', 40007, 70002),
	   ( 20002, 4, 1, '1300', 40008, 70002),
	   ( 20003, 1, 4, '190', 40009, 70001),
       ( 20003, 2, 7, '240', 40010, 70001),
	   ( 20003, 3, 1, '2800', 40011, 70001),
	   ( 20003, 4, 1, '1500', 40012, 70001),
	   ( 20004, 1, 6, '110', 40013, 70001),
       ( 20004, 2, 6, '140', 40014, 70001),
	   ( 20004, 3, 1, '2000', 40015, 70001),
	   ( 20004, 4, 1, '1300', 40016, 70001),
	   ( 20005, 1, 4, '110', 40005, 70002),
       ( 20005, 2, 4, '140', 40006, 70002),
	   ( 20005, 3, 1, '2000', 40007, 70002),
	   ( 20005, 4, 1, '1300', 40008, 70002),
	   ( 20006, 1, 6, '130', 40001, 70003), 
       ( 20006, 2, 6, '160', 40002, 70003),
	   ( 20006, 3, 1, '2200', 40003, 70003),
	   ( 20007, 1, 6, '190', 40009, 70004),
	   ( 20007, 2, 6, '240', 40010, 70004),
       ( 20007, 3, 1, '2800', 40011, 70004),
	   ( 20008, 1, 4, '190', 40009, 70005),
	   ( 20008, 2, 8, '240', 40010, 70005),
	   ( 20008, 3, 1, '2800', 40011, 70005),
       ( 20008, 4, 1, '1500', 40012, 70005),
	   ( 20009, 1, 3, '110', 40005, 70006),
	   ( 20009, 2, 4, '140', 40006, 70006),
	   ( 20009, 3, 1, '2000', 40007, 70006),
	   ( 20009, 4, 1, '1300', 40008, 70006),
	   ( 20010, 1, 8, '110', 40013, 70006),
	   ( 20010, 2, 8, '140', 40014, 70006),
	   ( 20010, 3, 1, '2000', 40015, 70006),
	   ( 20010, 4, 1, '1300', 40016, 70006),
	   ( 20011, 1, 8, '130', 40001, 70001),
       ( 20011, 2, 6, '160', 40002, 70001),
	   ( 20011, 3, 1, '2200', 40003, 70001),
	   ( 20011, 4, 1, '1500', 40004, 70001),
	   ( 20012, 1, 6, '110', 40005, 70006),
       ( 20012, 2, 8, '140', 40006, 70006),
	   ( 20012, 3, 1, '2000', 40007, 70006),
	   ( 20012, 4, 1, '1300', 40008, 70006),
	   ( 20013, 1, 7, '190', 40009, 70005),
       ( 20013, 2, 7, '240', 40010, 70005),
	   ( 20013, 3, 1, '2800', 40011, 70005),
	   ( 20013, 4, 1, '1500', 40012, 70005),
	   ( 20014, 1, 8, '110', 40013, 70001),
       ( 20014, 2, 6, '140', 40014, 70001),
	   ( 20014, 3, 1, '2000', 40015, 70001),
	   ( 20014, 4, 1, '1300', 40016, 70001),
	   ( 20015, 1, 4, '110', 40005, 70002),
       ( 20015, 2, 4, '140', 40006, 70002),
	   ( 20015, 3, 1, '2000', 40007, 70002),
	   ( 20015, 4, 1, '1300', 40008, 70002),
	   ( 20016, 1, 6, '130', 40001, 70003), 
       ( 20016, 2, 8, '160', 40002, 70003),
	   ( 20016, 3, 1, '2200', 40003, 70003),
	   ( 20017, 1, 6, '190', 40009, 70003),
	   ( 20017, 2, 6, '240', 40010, 70003),
       ( 20017, 3, 1, '2800', 40011, 70003),
	   ( 20018, 1, 8, '190', 40009, 70001),
	   ( 20018, 2, 8, '240', 40010, 70001),
	   ( 20018, 3, 1, '2800', 40011, 70001),
       ( 20018, 4, 1, '1500', 40012, 70001),
	   ( 20019, 1, 6, '110', 40005, 70005),
	   ( 20019, 2, 8, '140', 40006, 70005),
	   ( 20019, 3, 1, '2000', 40007, 70005),
	   ( 20019, 4, 1, '1300', 40008, 70005),
	   ( 20020, 1, 8, '110', 40013, 70003),
	   ( 20020, 2, 8, '140', 40014, 70003),
	   ( 20020, 3, 1, '2000', 40015, 70003),
	   ( 20020, 4, 1, '1300', 40016, 70003),
	   ( 20021, 1, 4, '130', 40001, 70001),
       ( 20021, 2, 4, '160', 40002, 70001),
	   ( 20021, 3, 1, '2200', 40003, 70001),
	   ( 20021, 4, 1, '1500', 40004, 70001),
	   ( 20022, 1, 6, '110', 40005, 70002),
       ( 20022, 2, 6, '140', 40006, 70002),
	   ( 20022, 3, 1, '2000', 40007, 70002),
	   ( 20022, 4, 1, '1300', 40008, 70002),
	   ( 20023, 1, 4, '190', 40009, 70001),
       ( 20023, 2, 7, '240', 40010, 70001),
	   ( 20023, 3, 1, '2800', 40011, 70001),
	   ( 20023, 4, 1, '1500', 40012, 70001),
	   ( 20024, 1, 6, '110', 40013, 70001),
       ( 20024, 2, 6, '140', 40014, 70001),
	   ( 20024, 3, 1, '2000', 40015, 70001),
	   ( 20024, 4, 1, '1300', 40016, 70001),
	   ( 20025, 1, 4, '110', 40005, 70002),
       ( 20025, 2, 4, '140', 40006, 70002),
	   ( 20025, 3, 1, '2000', 40007, 70002),
	   ( 20025, 4, 1, '1300', 40008, 70002),
	   ( 20026, 1, 6, '130', 40001, 70003), 
       ( 20026, 2, 6, '160', 40002, 70003),
	   ( 20026, 3, 1, '2200', 40003, 70003),
	   ( 20027, 1, 6, '190', 40009, 70004),
	   ( 20027, 2, 6, '240', 40010, 70004),
       ( 20027, 3, 1, '2800', 40011, 70004),
	   ( 20028, 1, 4, '190', 40009, 70005),
	   ( 20028, 2, 8, '240', 40010, 70005),
	   ( 20028, 3, 1, '2800', 40011, 70005),
       ( 20028, 4, 1, '1500', 40012, 70005),
	   ( 20029, 1, 3, '110', 40005, 70006),
	   ( 20029, 2, 4, '140', 40006, 70006),
	   ( 20029, 3, 1, '2000', 40007, 70006),
	   ( 20029, 4, 1, '1300', 40008, 70006),
	   ( 20030, 1, 8, '110', 40013, 70006),
	   ( 20030, 2, 8, '140', 40014, 70006),
	   ( 20030, 3, 1, '2000', 40015, 70006),
	   ( 20030, 4, 1, '1300', 40016, 70006),
	   ( 20031, 1, 8, '130', 40001, 70001),
       ( 20031, 2, 6, '160', 40002, 70001),
	   ( 20031, 3, 1, '2200', 40003, 70001),
	   ( 20031, 4, 1, '1500', 40004, 70001),
	   ( 20032, 1, 6, '110', 40005, 70006),
       ( 20032, 2, 8, '140', 40006, 70006),
	   ( 20032, 3, 1, '2000', 40007, 70006),
	   ( 20032, 4, 1, '1300', 40008, 70006),
	   ( 20033, 1, 7, '190', 40009, 70005),
       ( 20033, 2, 7, '240', 40010, 70005),
	   ( 20033, 3, 1, '2800', 40011, 70005),
	   ( 20033, 4, 1, '1500', 40012, 70005),
	   ( 20034, 1, 8, '110', 40013, 70001),
       ( 20034, 2, 6, '140', 40014, 70001),
	   ( 20034, 3, 1, '2000', 40015, 70001),
	   ( 20034, 4, 1, '1300', 40016, 70001),
	   ( 20035, 1, 4, '110', 40005, 70002),
       ( 20035, 2, 4, '140', 40006, 70002),
	   ( 20035, 3, 1, '2000', 40007, 70002),
	   ( 20035, 4, 1, '1300', 40008, 70002),
	   ( 20036, 1, 6, '130', 40001, 70003), 
       ( 20036, 2, 8, '160', 40002, 70003),
	   ( 20036, 3, 1, '2200', 40003, 70003),
	   ( 20037, 1, 6, '190', 40009, 70003),
	   ( 20037, 2, 6, '240', 40010, 70003),
       ( 20037, 3, 1, '2800', 40011, 70003),
	   ( 20038, 1, 8, '190', 40009, 70001),
	   ( 20038, 2, 8, '240', 40010, 70001),
	   ( 20038, 3, 1, '2800', 40011, 70001),
       ( 20038, 4, 1, '1500', 40012, 70001),
	   ( 20039, 1, 6, '110', 40005, 70005),
	   ( 20039, 2, 8, '140', 40006, 70005),
	   ( 20039, 3, 1, '2000', 40007, 70005),
	   ( 20039, 4, 1, '1300', 40008, 70005),
	   ( 20040, 1, 8, '110', 40013, 70003),
	   ( 20040, 2, 8, '140', 40014, 70003),
	   ( 20040, 3, 1, '2000', 40015, 70003),
	   ( 20040, 4, 1, '1300', 40016, 70003);

CREATE TABLE Product (
ProductID int,
ProductName varchar(50),
Color varchar(25),
ProductStandardCost money,
KitchenModelID int,
CONSTRAINT PK_Product_ProductID PRIMARY KEY (ProductID),
CONSTRAINT FK_Product_KitchenModel_KitchenModelID
        FOREIGN KEY (KitchenModelID)
		REFERENCES KitchenModel (KitchenModelID));

INSERT INTO Product
VALUES ( 40001, 'pensile', 'bianco', '100', 50001),
       ( 40002, 'base', 'bianco', '120', 50001),
	   ( 40003, 'top', 'bianco', '1500', 50001),
	   ( 40004, 'elettrodomestici', 'bianco', '1000', 50001),
	   ( 40005, 'pensile', 'nero', '80', 50002),
       ( 40006, 'base', 'nero', '100', 50002),
	   ( 40007, 'top', 'nero', '1700', 50002),
	   ( 40008, 'elettrodomestici', 'nero', '800', 50002),
	   ( 40009, 'pensile', 'legno', '150', 50003),
       ( 40010, 'base', 'legno', '200', 50003),
	   ( 40011, 'top', 'legno', '1900', 50003),
	   ( 40012, 'elettrodomestici', 'grigio opaco', '1000', 50003),
	   ( 40013, 'pensile', 'grigio', '70', 50004),
       ( 40014, 'base', 'grigio', '80', 50004),
	   ( 40015, 'top', 'grigio', '1400', 50004),
	   ( 40016, 'elettrodomestici', 'grigio', '1000', 50004);

CREATE TABLE KitchenModel (
KitchenModelID int,
KitchenName varchar(25),
CONSTRAINT PK_KitchenModel_KitchenModelID PRIMARY KEY (KitchenModelID));

INSERT INTO KitchenModel
VALUES (50001, 'Tabletneck'),
       (50002, 'Kyra'),
	   (50003, 'Imagine'),
	   (50004, 'Dream');

CREATE TABLE Reseller (
ResellerID int,
ResellerName varchar(25),
EmailAddress varchar (50),
WarehouseID int,
ReselleraddressID int,
CONSTRAINT PK_Reseller_ResellerID PRIMARY KEY (resellerID),
CONSTRAINT FK_Reseller_WarehouseID
       FOREIGN KEY (WarehouseID)
	   REFERENCES Warehouse (WarehouseID),
CONSTRAINT FK_Reseller_ResellerAddressID
       FOREIGN KEY (ResellerAddressID)
	   REFERENCES ResellerAddress (ResellerAddressID));

INSERT INTO Reseller 
VALUES ( 30001, 'Meb', 'lubetuscoalna@gmail.com', 60001, 330001),
       ( 30002, 'Ad Interni', 'lubeprati@gmail.com', 60001, 330002),
	   ( 30003, 'Aurelia', 'lubeaurelia@gmail.com', 60002, 330003);

CREATE TABLE ResellerAddress (
ResellerAddressID int,
ResellerAddress varchar(50),
NameCity varchar(25),
NameProvince varchar(25),
CONSTRAINT PK_ResellerAddress_ResellerAddressID PRIMARY KEY (ResellerAddressID));

INSERT INTO ResellerAddress
VALUES ( 330001, 'Via Tuscolana 324', 'Roma', 'Roma'),
       ( 330002, 'Via Prati 33', 'Roma', 'Roma'),
	   ( 330003, 'Via Aurelia 457', 'Roma', 'Roma');

CREATE TABLE Employee (
EmployeeID int,
FirstName varchar(25),
Lastname varchar(25),
EmailAddress varchar(50),
NumberPhone varchar(25),
Age int,
ResellerID int,
CONSTRAINT PK_Employee_EmployeeID PRIMARY KEY (EmployeeID),
CONSTRAINT FK_Employee_ResellerID
        FOREIGN KEY (ResellerID)
		REFERENCES Reseller (ResellerID));

INSERT INTO Employee
VALUES ( 70001, 'Filippo', 'Di Cosimo', 'filippolube@gmail.com', '3667829344', '44', 30001),
       ( 70002, 'Alessandro', 'Fragola', 'alessandrolube@gmail.com', '3387678922', '50', 30001),
	   ( 70003, 'Donato', 'Marca', 'donatolube@gmail.com', '3367782983', '65', 30002),
	   ( 70004, 'Marco', 'Bacchiocchi', 'marcolube�gmail.com', '3556728378', '48', 30002),
	   ( 70005, 'Mauro', 'Mulino', 'maurolube@gmail.com', '3662789367', '38', 30003),
	   ( 70006, 'Raimondo', 'Ursini', 'raimondolube@gmail.com', '3387890908', '28', 30003);

CREATE TABLE Warehouse (
WarehouseID int,
NameWarehouse varchar(50)
CONSTRAINT PK_Warehouse_WarehouseID PRIMARY KEY (WarehouseID));

INSERT INTO Warehouse 
VALUES ( 60001, 'Meb-AdInterni Warehouse'),
       ( 60002, 'Aurelia Warehouse');

CREATE TABLE StockManagement (
StockID int,
DateArrival date,
DateExit date,
WarehouseID int,
OrderID int,
CONSTRAINT PK_StockManagement_StockID PRIMARY KEY (StockID),
CONSTRAINT FK_StockManagement_WarehouseID
        FOREIGN KEY (WarehouseID)
		REFERENCES Warehouse (WarehouseID),
CONSTRAINT FK_StockManagement_SalesOrderHeader
        FOREIGN KEY (OrderID)
		REFERENCES SalesOrderHeader (OrderID));

INSERT INTO StockManagement
VALUES ( 80001, '02/03/2022', '04/04/2022', 60001, 20001),
       ( 80002, '05/03/2022', '03/04/2022', 60001, 20002),
	   ( 80003, '25/03/2022', '27/04/2022', 60001, 20003),
       ( 80004, '11/03/2022', '15/04/2022', 60001, 20004),
	   ( 80005, '24/03/2022', '28/04/2022', 60001, 20005),
       ( 80006, '11/03/2022', '15/04/2022', 60001, 20006),
	   ( 80007, '18/04/2022', '22/05/2022', 60001, 20007),
       ( 80008, '23/04/2022', '25/05/2022', 60002, 20008),
	   ( 80009, '01/04/2022', '01/05/2022', 60002, 20009),
       ( 80010, '22/04/2022', '24/05/2022', 60002, 20010),
	   ( 80011, '17/05/2022', '19/06/2022', 60001, 20011),
       ( 80012, '16/05/2022', '18/06/2022', 60002, 20012),
	   ( 80013, '26/05/2022', '28/06/2022', 60002, 20013),
       ( 80014, '12/05/2022', '15/06/2022', 60001, 20014),
	   ( 80015, '08/05/2022', '08/06/2022', 60001, 20015),
       ( 80016, '01/05/2022', '03/06/2022', 60001, 20016),
	   ( 80017, '03/06/2022', '05/07/2022', 60001, 20017),
       ( 80018, '07/06/2022', '08/07/2022', 60001, 20018),
	   ( 80019, '04/06/2022', '06/07/2022', 60002, 20019),
       ( 80020, '20/06/2022', '20/07/2022', 60001, 20020),
	   ( 80021, '02/07/2022', null, 60001, 20021),
       ( 80022, '05/07/2022', null, 60001, 20022),
	   ( 80023, '25/07/2022', null, 60001, 20023),
       ( 80024, '11/07/2022', null, 60001, 20024),
	   ( 80025, '24/07/2022', null, 60001, 20025),
       ( 80026, '11/07/2022', null, 60001, 20026),
	   ( 80027, '18/08/2022', null, 60001, 20027),
       ( 80028, '23/08/2022', null, 60002, 20028),
	   ( 80029, '01/08/2022', null, 60002, 20029),
       ( 80030, '22/08/2022', null, 60002, 20030),
	   ( 80031, '17/08/2022', null, 60001, 20031),
       ( 80032, '16/08/2022', null, 60002, 20032),
	   ( 80033, '26/08/2022', null, 60002, 20033),
       ( 80034, '12/08/2022', null, 60001, 20034),
	   ( 80035, '08/09/2022', null, 60001, 20035),
       ( 80036, '01/09/2022', null, 60001, 20036),
	   ( 80037, '03/09/2022', null, 60001, 20037),
       ( 80038, '07/09/2022', null, 60001, 20038),
	   ( 80039, '04/09/2022', null, 60002, 20039),
       ( 80040, '20/09/2022', null, 60001, 20040);


--interrogare i dati


-- Calcolo profitto annuale per negozio

SELECT r.ResellerID, 
r.ResellerName, 
SUM(Quantity * UnitPrice) AS SalesAmount , 
SUM(Quantity * ProductStandardCost) AS TotalProductCost ,  
SUM(Quantity * UnitPrice) - SUM(Quantity * ProductStandardCost) AS ProfitYear
FROM Employee e
INNER JOIN SalesOrderDetail s
ON e.EmployeeID = s.EmployeeID
INNER JOIN Reseller AS r
ON r.ResellerID = e.ResellerID
INNER JOIN Product AS p
ON s.ProductID = p.ProductID
GROUP BY r.ResellerID, r.ResellerName
ORDER BY ProfitYear DESC


-- calcolo fatturato per impiegato

SELECT e.FirstName, e.EmployeeID, SUM(Quantity * UnitPrice) AS EmployeeSalesYear
FROM Employee e
INNER JOIN SalesOrderDetail s
ON e.EmployeeID = s.EmployeeID
GROUP BY e.FirstName, e.EmployeeID
ORDER BY EmployeeSalesYear DESC


--lista cucine presenti in magazzino e quelle ancora da montare

SELECT CONCAT(c.FirstName, ' ', c.LastName) AS NomeCliente
      , sm.OrderID
	  , sm.WarehouseID
	  , soh.OrderDate
      , sm.DateArrival
	  , sm.DateExit
	  , CASE 
	  WHEN sm.DateExit is not null THEN 'cucina montata'
	  WHEN sm.DateExit is null THEN 'in magazzino'
	  END FlagAttivo
FROM StockManagement AS sm
INNER JOIN SalesOrderHeader AS soh
ON sm.OrderID = soh.OrderID
INNER JOIN Customer AS c
ON soh.CustomerID = c.CustomerID


--cucina pi� venduta, prezzo produzione, prezzo vendita, guadagno

SELECT k.KitchenName
, k.KitchenModelID
, SUM(ProductStandardCost * Quantity) AS TotalProductCost
, SUM(UnitPrice * quantity) AS SalesAmount
, SUM(Quantity * UnitPrice) - SUM(Quantity * ProductStandardCost) AS Profit
FROM SalesOrderDetail AS sod
INNER JOIN Product AS p
ON sod.ProductID = p.ProductID
INNER JOIN KitchenModel AS k
ON p.KitchenModelID = k.KitchenModelID
INNER JOIN SalesOrderHeader soh
ON soh.OrderID = sod.OrderID
GROUP BY k.KitchenName, k.KitchenModelID


--elenco vendite per citt�

SELECT DISTINCT ca.NameCity
               , COUNT(soh.OrderID) CNTvendite
FROM CustomerAddress AS ca
INNER JOIN Customer AS c
ON ca.CustomerAddressID = c.CustomerAddressID
INNER JOIN SalesOrderHeader AS soh
ON c.CustomerID = soh.CustomerID
GROUP BY ca.NameCity
ORDER BY CNTvendite DESC


--Fatturato per prodotto

SELECT sod.ProductID, SUM(UnitPrice * Quantity) AS SalesAmount
FROM SalesOrderDetail AS sod
INNER JOIN SalesOrderHeader AS soh
ON sod.OrderID = soh.OrderID
WHERE YEAR(OrderDate) = 2022
GROUP BY sod.ProductID


--clienti residenti a Roma con et� media < di 50 anni

SELECT c.CustomerID, ca.CustomerAddressID, ca.NameCity, c.Age
FROM Customer AS c
INNER JOIN CustomerAddress AS ca
ON c.CustomerAddressID = ca.CustomerAddressID
GROUP BY ca.CustomerAddressID, c.CustomerID, ca.NameCity, c.Age
HAVING ca.NameCity = 'Roma' AND AVG(Age) < 50







